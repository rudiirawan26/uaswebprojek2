<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title;  ?></h1>


    <div class="row">
        <div class="col-lg">
            <a href="<?= base_url();  ?>home/isiloker" class="btn btn-primary mb-3" data-toggle="modal" data-target="#newSubMenuModal"> Tambah Lowongan Kerja</a>

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Deskripsi pekerjaan</th>
                        <th scope="col">Tanggal akhir</th>
                        <th scope="col">Mitra ID</th>
                        <th scope="col">email</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($lowongan as $loker) : ?>
                        <tr>
                            <th scope="row"><?= $i; ?></th>
                            <td><?= $loker['deskripsi_pekerjaan'];  ?></td>
                            <td><?= $loker['tanggal_akhir'];  ?></td>
                            <td><?= $loker['mitra_id'];  ?></td>
                            <td><?= $loker['email'];  ?></td>
                            <td>
                                <a href="" class="badge badge-success">Edit</a>
                                <a href="<?= base_url()  ?>lowongan/hapus" class="badge badge-danger" onclick="retrunconfrim('yakin');">Delete</a>
                            </td>
                        </tr>
                        <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>



</div>
<!-- /.container-fluid -->