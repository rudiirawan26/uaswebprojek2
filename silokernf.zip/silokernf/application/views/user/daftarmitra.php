<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title;  ?></h1>


    <div class="row">
        <div class="col-lg">
            <a href="<?= base_url('daftarmitra');  ?>" class="btn btn-primary mb-3" data-toggle="modal" data-target="#newSubMenuModal"> Tambah Mitra</a>
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">No</th>
                        <th scope="col">Deskripsi pekerjaan</th>
                        <th scope="col">Tanggal akhir</th>
                        <th scope="col">Mitra ID</th>
                        <th scope="col">email</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php foreach ($mitra as $mt) : ?>
                        <tr>
                            <th scope="row"><?= $i; ?></th>
                            <td><?= $mt['nama'];  ?></td>
                            <td><?= $mt['alamat'];  ?></td>
                            <td><?= $mt['kontak'];  ?></td>
                            <td><?= $mt['telpon'];  ?></td>
                            <td><?= $mt['email'];  ?></td>
                            <td><?= $mt['web'];  ?></td>
                            <td>
                                <a href="" class="badge badge-success">Edit</a>
                                <a href="" class="badge badge-danger">Delete</a>
                            </td>
                        </tr>
                        <?php $i++; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>



</div>
<!-- /.container-fluid -->