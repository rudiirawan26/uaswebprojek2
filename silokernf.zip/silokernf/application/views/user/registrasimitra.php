<!-- Halaman Form isi jadi mitra -->
<div class="container ">
    <div class="row">
        <div class="col">
            <div class="card border-0" style=" box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);">
                <div class="card-header text-center p-1 border-0">
                    <h5>Lowongan Kerja Terbaru di STT-NF</h5>
                </div>
                <div class="card mb-3 mt-3 bg-transparent border-0 ">
                    <form class="form-isi-loker">
                        <div class="container">
                            <div class="form-group row">
                                <label for="text1" class="col-lg-3 col-form-label">Nama
                                    Perusahaan/Organisasi</label>
                                <div class="col-lg-9">
                                    <input class="form-control" type="text" id="text1" required="required" placeholder="Nama Perusahaan" id="text1">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="select" class="col-lg-3 col-form-label">Bidang Usaha</label>
                                <div class="col-lg-9">
                                    <select id="select" name="select" class="custom-select" required="required">
                                        <option hidden value="">Open this select menu</option>
                                        <option value="1">Teknologi</option>
                                        <option value="2">Perbankan</option>
                                        <option value="3">Makanan</option>
                                        <option value="3">Testisl</option>
                                        <option value="3">Perternakan</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="exampleTextarea" class="col-lg-3 col-form-label">Alamat Kantor</label>
                                <div class="col-lg-9">
                                    <textarea rows="7" class="form-control" id="exampleTextarea" required="required" rows="3" placeholder="Alamat kantor"></textarea>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="example-tel-input" class="col-lg-3 col-form-label">No
                                    HP/Telephone</label>
                                <div class="col-lg-9">
                                    <input class="form-control" type="tel" required="required" placeholder="085769339687" required="required" id="example-tel-input">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="example-email-input" class="col-lg-3 col-form-label">Email</label>
                                <div class="col-lg-9">
                                    <input class="form-control" type="email" required="required" placeholder="example@gmail.com" id="example-email-input">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="example-email-input" class="col-lg-3 col-form-label">Alamat Web</label>
                                <div class="col-lg-9">
                                    <input class="form-control" type="url" required="required" placeholder="http://example.com" id="example-url-input">
                                </div>
                            </div>
                            <hr>
                            <div class="btn-form-isi-loker">
                                <button class="btn btn-success text-white" name="submit" type="submit" class="btn btn-outline-primary" data-target="#daftar-mitra">Daftar</button>

                                <a href="daftar_mitra.html" class="btn btn-danger text-white" type="button">Batal</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>
<!-- Akhir Halaman Form isi jadi mitra  -->


<!-- Modal -->
<div class="modal fade" id="daftar-mitra" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <div class="modal-body text-center">
                <i class="far fa-handshake text-center d-block mb-3" style="font-size: 100px; color: #28A745;"></i>
                <h3 style="color: #505050; font-family: Noto Sans; font-weight: 600; text-align: center; font-size: 25px;">
                    Sukses
                    Menjadi Mitra</h3>
                <p class="mb-4" style="color: #7A7878; text-align: center; font-size: 14px;">Selamat anda telah
                    terdaftar menjadi
                    mitra kami,
                    Semoga kedepanya kami akan semakin maju & menjadi lebih baik</p>
                <a href="index.html" type="button" class="btn" data-dismiss="modal" style="background-color: #ECF0F5; width: 150px; color: #B7B7B7;">Close</a>
            </div>
        </div>
    </div>
</div>
<!-- Akhir Modal -->