<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title;  ?></h1>

    <!-- Konten -->
    <div class="card mb-4">
        <a href="form_isi_berita_adm.html">
            <div class="btn btn-warning ml-4 mt-2" style="color: white; background-color: #FF8E32;">
                <i class="fas fa-plus-square"></i>
                Buat Postingan Baru
            </div>
        </a>
        <div class="card-body pt-2">
            <div class="table-responsive pb-0">
                <div class="card mb-3">
                    <div class="row no-gutters">
                        <div class="col-md-2 p-2">
                            <img src="<?= base_url('assets/'); ?>img/berita/adm_berita/1.png" class="card-img" alt="...">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body p-1">
                                <h5 class="card-title">Hal yang Wajib Dimiliki Setiap Individu agar Siap
                                    Hadapi</h5>
                                <p class="card-text m-0">Hal yang Wajib Dimiliki Setiap Individu agar
                                    Siap Hadapi Dunia...</p>
                                <p class="card-text"><small class="text-muted">Publikasi, 26 Januari
                                        2020</small></p>
                            </div>
                        </div>
                        <div class="col-md-2 align-self-center p-2 d-flex flex-row-reverse">
                            <a href="#" type="button" class="btn btn-danger p-2 m-2" data-toggle="tooltip" data-placement="top" title="Hapus" style="height: 40px; width: 40px;"><i class="fas fa-trash-alt text-white rounded"></i></a>
                            <a href="form_isi_berita_adm.html" type="button" class="btn btn-success p-2 m-2" data-toggle="tooltip" data-placement="top" title="Edit" style="height: 40px; width: 40px;"><i class="fas fa-edit text-white rounded"></i></a>
                        </div>
                    </div>
                </div>
                <div class="card mb-3">
                    <div class="row no-gutters">
                        <div class="col-md-2 p-2">
                            <img src="<?= base_url('assets/'); ?>img/berita/adm_berita/2.png" class="card-img" alt="...">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body p-1">
                                <h5 class="card-title">Tips agar Tetap Bahagia Saat Terjun di Dunia
                                    Kerja!</h5>
                                <p class="card-text m-0">Punya pekerjaan yang sesuai dengan keahlian
                                    dan...</p>
                                <p class="card-text"><small class="text-muted">Publikasi, 25 Januari
                                        2020</small></p>
                            </div>
                        </div>
                        <div class="col-md-2 align-self-center p-2 d-flex flex-row-reverse">
                            <a href="#" type="button" class="btn btn-danger p-2 m-2" data-toggle="tooltip" data-placement="top" title="Hapus" style="height: 40px; width: 40px;"><i class="fas fa-trash-alt text-white rounded"></i></a>
                            <a href="form_isi_berita_adm.html" type="button" class="btn btn-success p-2 m-2" data-toggle="tooltip" data-placement="top" title="Edit" style="height: 40px; width: 40px;"><i class="fas fa-edit text-white rounded"></i></a>
                        </div>
                    </div>
                </div>
                <div class="card mb-3">
                    <div class="row no-gutters">
                        <div class="col-md-2 p-2">
                            <img src="<?= base_url('assets/'); ?>img/berita/adm_berita/3.png" class="card-img" alt="...">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body p-1">
                                <h5 class="card-title">Riset Menunjukan Bahwa 37 Persen Tenaga Kerja
                                </h5>
                                <p class="card-text m-0">Kemajuan inovasi teknologi yang begitu pesat
                                    dan...</p>
                                <p class="card-text"><small class="text-muted">Publikasi, 20 Januari
                                        2020</small></p>
                            </div>
                        </div>
                        <div class="col-md-2 align-self-center p-2 d-flex flex-row-reverse">
                            <a href="#" type="button" class="btn btn-danger p-2 m-2" data-toggle="tooltip" data-placement="top" title="Hapus" style="height: 40px; width: 40px;"><i class="fas fa-trash-alt text-white rounded"></i></a>
                            <a href="form_isi_berita_adm.html" type="button" class="btn btn-success p-2 m-2" data-toggle="tooltip" data-placement="top" title="Edit" style="height: 40px; width: 40px;"><i class="fas fa-edit text-white rounded"></i></a>
                        </div>
                    </div>
                </div>
                <div class="card mb-3">
                    <div class="row no-gutters">
                        <div class="col-md-2 p-2">
                            <img src="<?= base_url('assets/'); ?>img/berita/adm_berita/4.png" class="card-img" alt="...">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body p-1">
                                <h5 class="card-title">5 Cara Milenial Mempengaruhi Dunia Kerja di 2021
                                </h5>
                                <p class="card-text m-0">Generasi milenial telah melakukan banyak
                                    perubahan...</p>
                                <p class="card-text"><small class="text-muted">Publikasi, 18 Januari
                                        2020</small></p>
                            </div>
                        </div>
                        <div class="col-md-2 align-self-center p-2 d-flex flex-row-reverse">
                            <a href="#" type="button" class="btn btn-danger p-2 m-2" data-toggle="tooltip" data-placement="top" title="Hapus" style="height: 40px; width: 40px;"><i class="fas fa-trash-alt text-white rounded"></i></a>
                            <a href="form_isi_berita_adm.html" type="button" class="btn btn-success p-2 m-2" data-toggle="tooltip" data-placement="top" title="Edit" style="height: 40px; width: 40px;"><i class="fas fa-edit text-white rounded"></i></a>
                        </div>
                    </div>
                </div>
                <div class="card mb-3">
                    <div class="row no-gutters">
                        <div class="col-md-2 p-2">
                            <img src="<?= base_url('assets/'); ?>img/berita/adm_berita/5.png" class="card-img" alt="...">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body p-1">
                                <h5 class="card-title">Dunia Industri Didorong Tingkatkan Kualitas</h5>
                                <p class="card-text m-0">Pemerintah mendorong dunia industri (swasta)
                                    agar...</p>
                                <p class="card-text"><small class="text-muted">Publikasi, 16 Januari
                                        2020</small></p>
                            </div>
                        </div>
                        <div class="col-md-2 align-self-center p-2 d-flex flex-row-reverse">
                            <a href="#" type="button" class="btn btn-danger p-2 m-2" data-toggle="tooltip" data-placement="top" title="Hapus" style="height: 40px; width: 40px;"><i class="fas fa-trash-alt text-white rounded"></i></a>
                            <a href="form_isi_berita_adm.html" type="button" class="btn btn-success p-2 m-2" data-toggle="tooltip" data-placement="top" title="Edit" style="height: 40px; width: 40px;"><i class="fas fa-edit text-white rounded"></i></a>
                        </div>
                    </div>
                </div>
                <!-- Pagination -->
                <nav aria-label="..." class="justify-content-center d-flex pb-0">
                    <ul class="pagination">
                        <li class="page-item disabled">
                            <span class="page-link">Previous</span>
                        </li>
                        <li class="page-item active"><a class="page-link" href="berita_adm.html">1</a>
                        </li>
                        <li class="page-item"><a class="page-link" href="berita_adm.html">2</a></li>
                        <li class="page-item"><a class="page-link" href="berita_adm.html">3</a></li>
                        <li class="page-item">
                            <a class="page-link" href="berita_adm.html">Next</a>
                        </li>
                    </ul>
                </nav>

            </div>
        </div>
    </div>
</div>