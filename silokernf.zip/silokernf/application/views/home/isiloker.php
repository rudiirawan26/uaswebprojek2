    <!-- Halaman Form isi Loker -->
    <div class="container " style="margin-top: 70px;">
        <div class="row">
            <div class="col ">

                <div class="card border-0" style=" box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);">
                    <div class="card-header text-center p-1 border-0">
                        <h5>Isi Penawaran Lowongan Kerja Anda</h5>
                    </div>
                    <div class="card-body ">
                        <?php if (validation_errors()) : ?>
                            <div class="alert alert-danger" role="alert">
                                <?= validation_errors();  ?>
                            </div>
                        <?php endif; ?>

                        <form class="form-isi-loker" action="" method="post">
                            <div class="container">



                                <div class="form-group row">

                                    <label for="nama_perusahaan" class="col-lg-3 col-form-label">Nama
                                        Perusahaan/Organisasi</label>
                                    <div class="col-lg-9">
                                        <input class="form-control" type="text" placeholder="Nama Perusahaan" id="nama" name="nama">
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="bidang_usaha" class="col-lg-3 col-form-label">Bidang Usaha</label>
                                    <div class="col-lg-9">
                                        <select id="bidang_usaha" name="bidang_usaha" class="custom-select" required="required">
                                            <option selected>Open this select menu</option>
                                            <option value="1">Teknologi Informasi dan Komunikasi</option>
                                            <option value="2">Perbankan</option>
                                            <option value="3">Transporasi</option>
                                            <option value="3">Industri Nasional</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="deskripsi_lowongan" class="col-lg-3 col-form-label">Deskripsi
                                        Lowongan</label>
                                    <div class="col-lg-9">
                                        <textarea rows="7" class="form-control" id="deskripsi_lowongan" rows="3" placeholder=" Tulis Deskripsi Lowongan" name="deskripsi_lowongan"></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="exampleTextarea" class="col-lg-3 col-form-label">Kategori
                                        Lowongan</label>
                                    <div class="col-lg-9 pr-5">
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                                            <label class="form-check-label" for="inlineCheckbox1">Programmer</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                                            <label class="form-check-label" for="inlineCheckbox2">
                                                Infrastruktur & Jaringan</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                                            <label class="form-check-label" for="inlineCheckbox1">Accounting</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                                            <label class="form-check-label" for="inlineCheckbox2">Bahasa Inggris</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                                            <label class="form-check-label" for="inlineCheckbox2">Database</label>
                                        </div>
                                        <div class="form-check form-check-inline">
                                            <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                                            <label class="form-check-label" for="inlineCheckbox2">Web Design</label>
                                        </div>

                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="date" class="col-lg-3 col-form-label">Tanggal
                                        Deadline</label>
                                    <div class="col-lg-9">
                                        <input class="form-control" type="date" placeholder="26-01-2020" id="date">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="kontak_person" class="col-lg-3 col-form-label">Kontak Person</label>
                                    <div class="col-lg-9">
                                        <input class="form-control" type="text" placeholder="0857693xxxx" id="kontak_person" name="kontak_person">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="email" class="col-lg-3 col-form-label">Email</label>
                                    <div class="col-lg-9">
                                        <input class="form-control" type="text" placeholder="example@gmail.com" id="email" name="email">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="email" class="col-lg-3 col-form-label">Id Mitra</label>
                                    <div class="col-lg-9">
                                        <input class="form-control" type="text" placeholder="" id="email" name="email">
                                    </div>
                                </div>
                                <hr>
                                <div class="btn-form-isi-loker">
                                    <button class="btn" style="background-color: #F9B234; color: white;" name="tambah" id="tambah" type="submit" name="tambah" class="btn btn-outline-primary">Submit</button>
                                    <button class="btn" type="reset" style="background-color: #F6F7FB; color: #ADADAD;">Reset</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <!-- Akhir Halaman Form isi Loker  -->