<!-- Daftar Kelompok -->
<div class="container" style="margin-top: 50px;">
    <section class="pem-inti-daf-kel">
        <div class="row">
            <div class="col pem-jud-kel">
                <h1 style="font-weight: 600;">PROJECT KELOMPOK 3</h1>
                <p>SILOKERNF merupakan Sistem Informasi Lowongan kerja online, Sistem informasi ini dibuat oleh
                    kelompok 3 kelas SI03 STTNF dengan tujuan penyempurnaan tugas akhir kuliah semester 1.</p>
            </div>
        </div>
        <div class="row">
            <div class=""></div>
            <div class="col pem-jud-card mb-4">
                <div class="card border-0" style="width: 15rem;box-shadow: 5px 5px 30px rgba(0, 0, 0, 0.1); color: #666666; ">
                    <div class="card-header p-2 text-white" style="font-weight: 600;font-size: 20px;">
                        Anggota 1
                    </div>
                    <div class="row">
                        <div class="col">
                            <img class="img-anggota mt-4 mb-2 " src="<?= base_url('assets/'); ?>img/foto_kelompok/rudi_irawan.png" alt="">
                            <div class="card-body " style="font-size: 14px;">
                                <p class="card-text mb-2"><b>NAMA : </b>Rudi irawan</p>
                                <p class="card-text mb-2"><b>NIM : </b>0110120083</p>
                                <p class="card-text mb-2"><b>Jurusan : </b>Sistem Informasi</p>
                                <p class="card-text mb-2"><b>Kelas : </b>SI03</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div class="col pem-jud-card mb-4 ">
                <div class="card border-0" style="width: 15rem;box-shadow: 5px 5px 30px rgba(0, 0, 0, 0.1); color: #666666; ">
                    <div class="card-header p-2 text-white" style="font-weight: 600;font-size: 20px;">
                        Anggota 2
                    </div>
                    <div class="row">
                        <div class="col">
                            <img class="img-anggota mt-4 mb-2 " src="<?= base_url('assets/'); ?>img/foto_kelompok/Dyah_najunda_salsabila.png" alt="">
                            <div class="card-body " style="font-size: 14px;">
                                <p class="card-text mb-2"><b>NAMA : </b>Dyah Najunda Salsabila</p>
                                <p class="card-text mb-2"><b>NIM : </b>0110120026</p>
                                <p class="card-text mb-2"><b>Jurusan : </b>Sistem Informasi</p>
                                <p class="card-text mb-2"><b>Kelas : </b>SI03</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col pem-jud-card mb-4">
                <div class="card border-0" style="width: 15rem;box-shadow: 5px 5px 30px rgba(0, 0, 0, 0.1); color: #666666; ">
                    <div class="card-header p-2 text-white" style="font-weight: 600;font-size: 20px;">
                        Anggota 3
                    </div>
                    <div class="row">
                        <div class="col">
                            <img class="img-anggota mt-4 mb-2 " src="<?= base_url('assets/'); ?>img/foto_kelompok/Fajar_nofrian_syahputra.png" alt="">
                            <div class="card-body " style="font-size: 14px;">
                                <p class="card-text mb-2"><b>NAMA : </b>Fajar Nofrian Syahputra</p>
                                <p class="card-text mb-2"><b>NIM : </b>0110120193</p>
                                <p class="card-text mb-2"><b>Jurusan : </b>Sistem Informasi</p>
                                <p class="card-text mb-2"><b>Kelas : </b>SI03</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col card-text pt-3">
                <p>Terima kasih telah berkunjung di web site kami! Jika anda merasa sistem yang kami buat ada
                    masalah, anda bisa mengirimkan email ke silokernf123@gmail.co.id</p>
            </div>
        </div>
    </section>
</div>
<!-- Daftar Kelompok -->