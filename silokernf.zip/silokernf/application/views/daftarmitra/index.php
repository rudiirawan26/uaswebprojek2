<section class="mitra">
    <!-- Halaman Daftar Mitra  -->
    <div class="container" style="margin-top: 80px;">

        <div class="row">
            <div class="col">

                <div class="card border-0 pem-daf-mitra pb-0" style=" box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);">

                    <div class="card-header text-center p-1 border-0">
                        <h5>Mitra Perusahaan Kami</h5>
                    </div>
                    <?php foreach ($mitra as $m) : ?>
                        <div class="card mb-3 bg-transparent border-0 daf-mitra">
                            <div class="row no-gutters">
                                <div class="col-md-9 col-lg-10">
                                    <div class="card-body ket-daf-mitra">
                                        <h1 class="card-title-1"><?= $m['nama'];  ?></h1>
                                        <h5 class="card-title-2"><?= $m['email'];  ?></h5>
                                        <p><?= $m['deskripsi'];  ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <!-- Tombol Daftar Mitra -->
                    <div class="container pb-4 tom-daf-mit ">
                        <a href="<?= base_url('daftarmitra/');  ?>/home/registrasimitra" class="btn d-flex justify-content-center">Daftar Menjadi
                            Mitra Sekarang Juga <i class="fas fa-mouse-pointer pl-3 pt-2"></i></a>
                    </div>

                    <!-- Akhir Tombol Daftar Mitra -->
                    <hr class="m-0" style="color: #f3f3f3;">

                    <hr class="m-2" style="border: 0 black;">

                    <!-- Pagination -->
                    <nav aria-label="...">
                        <ul class="pagination justify-content-center mb-2" style="transform: scale(0.7);">
                            <li class="page-item disabled">
                                <span class="page-link">Previous</span>
                            </li>
                            <li class="page-item active"><a class="page-link" href="daftar_mitra.html">1</a></li>
                            <li class="page-item"><a class="page-link" href="daftar_mitra_2.html">2</a></li>
                            <li class="page-item"><a class="page-link" href="daftar_mitra_3.html">3</a></li>
                            <li class="page-item">
                                <a class="page-link" href="daftar_mitra.html">Next</a>
                            </li>
                        </ul>
                    </nav>
                    <!-- Pagination -->

                </div>
            </div>

        </div>
    </div>
    <!-- Akhir Daftar Daftar Mitra  -->
</section>