<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Daftarberita extends CI_Controller
{

    public function index()
    {
        $data['title'] = 'Berita Terkini';
        $this->load->view('templates/header_home', $data);
        $this->load->view('templates/navbar_home');
        $this->load->view('home/daftarberita');
        $this->load->view('templates/footer_home');
    }
}
