<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Daftarkelompok extends CI_Controller
{

    public function index()
    {
        $data['title'] = 'Daftar kelompok';
        $this->load->view('templates/header_home', $data);
        $this->load->view('templates/navbar_home');
        $this->load->view('home/daftarkelompok');
        $this->load->view('templates/footer_home');
    }
}
