<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Isiloker extends CI_Controller
{
    public function index()
    {
        $data['title'] = 'Isi Lowongan kerja';
        $this->load->view('templates/header_home', $data);
        $this->load->view('templates/navbar_home');
        $this->load->view('home/isiloker');
        $this->load->view('templates/footer_home');
    }
}
