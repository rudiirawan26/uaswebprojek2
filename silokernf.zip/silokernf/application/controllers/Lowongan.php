<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Lowongan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Lowongan_model');
        $this->load->library('form_validation');
        $this->load->model('Usaha_model');
    }
    public function index()
    {
        $data['title'] = 'Daftar Lowongan';
        $data['lowongan'] = $this->Lowongan_model->getAllLowongan();
        $this->load->view('templates/header_home', $data);
        $this->load->view('templates/navbar_home');
        $this->load->view('home/lowongan', $data);
        $this->load->view('templates/footer_home');
    }

    public function registrasiMitra()
    {
        $data['title'] = 'registrasimitra';
        $data['bidang_usaha'] = $this->Usaha_model->getAllUsaha();

        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('contact', 'Contact', 'required|numeric');
        if ($this->form_validation->run() == FALSE) {

            $this->load->view('templates/header_home', $data);
            $this->load->view('templates/navbar_home');
            $this->load->view('home/lowongan', $data);
            $this->load->view('templates/footer_home');
        } else {
            $this->Mahasiswa_model->tambahdataLoker();
            redirect('lowongan');
        }
    }
}
